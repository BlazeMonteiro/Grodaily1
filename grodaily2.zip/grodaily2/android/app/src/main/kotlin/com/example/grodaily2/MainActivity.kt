package com.example.grodaily2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
